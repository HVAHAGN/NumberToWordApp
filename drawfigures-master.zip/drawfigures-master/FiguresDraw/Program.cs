﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace FiguresDraw
{
    class Program
    {
        static void Main(string[] args)
        {
            //Line li = new Line(30);
            //li.Draw(li);
            //li.LineInfo(li);

            //Arrow arr = new Arrow('-');
            //arr.Draw(arr);
            //arr.ArrowInfo(arr);

            //Square sq = new Square(15,'/');
            //sq.Draw(sq);
            //sq.SquareInfo(sq);

            //Rectangle rec = new Rectangle(25,15,'m');
            //rec.Draw(rec);
            //rec.RectInfo(rec);

            //Triangle tri = new Triangle(15,20,'-');
            //Draw(tri);
            //tri.TriangleInfo(tri);
         
            Read();
        }
    }
}